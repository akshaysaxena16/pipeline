#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   scripts/detect_stepfunctions_changes.sh <base_sha> <head_sha>
#
# Outputs to stdout in a simple, parseable format:
#   DEPLOY:<path>   (definition file path to create/update)
#   DELETE:<id>     (workflow id to delete; derived from removed file name)
#
# Rules:
# - If env files changed, we deploy ALL current definitions (safe default).
# - If manifest changed, we deploy ONLY workflows whose manifest entry changed (new/modified),
#   plus any directly changed definition files.
# - Deletes are still detected from git diff and emitted.

BASE_SHA="${1:-}"
HEAD_SHA="${2:-}"

if [[ -z "$BASE_SHA" || -z "$HEAD_SHA" ]]; then
  echo "Usage: $0 <base_sha> <head_sha>" >&2
  exit 2
fi

DEF_GLOB='stepfunctions/definitions/*.asl.json'

manifest_changed="$(git diff --name-only "$BASE_SHA" "$HEAD_SHA" -- stepfunctions/manifest.json || true)"
env_changed="$(git diff --name-only "$BASE_SHA" "$HEAD_SHA" -- stepfunctions/env || true)"

declare -A deploy=()
declare -A delete=()

_add_deploy() {
  while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    deploy["$f"]=1
  done
}

if [[ -n "${env_changed//[[:space:]]/}" ]]; then
  # Any env change can affect rendering across workflows, so redeploy all.
  _add_deploy < <(git ls-files "$DEF_GLOB")
else
  # Always include directly changed definitions.
  _add_deploy < <(git diff --name-only "$BASE_SHA" "$HEAD_SHA" -- "$DEF_GLOB" 2>/dev/null || true)

  # If manifest changed, deploy only workflows whose entry changed.
  if [[ -n "${manifest_changed//[[:space:]]/}" ]]; then
    base_tmp="$(mktemp)"
    head_tmp="$(mktemp)"
    trap 'rm -f "$base_tmp" "$head_tmp"' EXIT

    # Base/head manifest snapshots
    git show "${BASE_SHA}:stepfunctions/manifest.json" >"$base_tmp" 2>/dev/null || echo '{}' >"$base_tmp"
    git show "${HEAD_SHA}:stepfunctions/manifest.json" >"$head_tmp" 2>/dev/null || echo '{}' >"$head_tmp"

    # If a workflow was removed from the manifest, delete it (even if the
    # definition file still exists in the repo).
    while IFS= read -r id; do
      [[ -z "$id" ]] && continue
      delete["$id"]=1
    done < <(
      jq -r -n --slurpfile b "$base_tmp" --slurpfile h "$head_tmp" '
        ($b[0].workflows // []) | map(.id) as $bids
        | ($h[0].workflows // []) | map(.id) as $hids
        | $bids[]
        | . as $id
        | select(($hids | index($id)) == null)
      ' 2>/dev/null || true
    )

    # Emit definition paths for workflows that are new/modified in HEAD vs BASE.
    _add_deploy < <(
      jq -r -n --slurpfile b "$base_tmp" --slurpfile h "$head_tmp" '
        def wfmap($wfs): reduce ($wfs // [])[] as $w ({}; .[$w.id] = $w);
        ($b[0].workflows // []) as $bw
        | ($h[0].workflows // []) as $hw
        | (wfmap($bw)) as $bm
        | $hw[]
        | select((($bm[.id] // null) | tostring) != (.|tostring))
        | .definition
      ' 2>/dev/null || true
    )
  fi
fi

# Detect deletes/renames.
# name-status outputs:
#  D <path>
#  R100 <old> <new>
while IFS=$'\t' read -r status p1 p2; do
  [[ -z "$status" ]] && continue

  case "$status" in
    D)
      if [[ "$p1" == stepfunctions/definitions/*.asl.json ]]; then
        id="$(basename "$p1" .asl.json)"
        delete["$id"]=1
      fi
      ;;
    R*)
      if [[ "$p1" == stepfunctions/definitions/*.asl.json ]]; then
        old_id="$(basename "$p1" .asl.json)"
        delete["$old_id"]=1
      fi
      if [[ "$p2" == stepfunctions/definitions/*.asl.json ]]; then
        deploy["$p2"]=1
      fi
      ;;
  esac
done < <(git diff --name-status "$BASE_SHA" "$HEAD_SHA" -- "$DEF_GLOB" || true)

for f in "${!deploy[@]}"; do
  echo "DEPLOY:$f"
done
for id in "${!delete[@]}"; do
  echo "DELETE:$id"
done
